package Common.Object

case class ParameterList(l:List[SqlParameter])

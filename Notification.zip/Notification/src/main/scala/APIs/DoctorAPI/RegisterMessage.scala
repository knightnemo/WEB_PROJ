package APIs.DoctorAPI


case class RegisterMessage(userName:String) extends DoctorMessage[Int]

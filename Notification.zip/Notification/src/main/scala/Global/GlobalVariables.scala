package Global

import Global.ServiceCenter.notificationServiceCode

object GlobalVariables:
  val serviceCode:String= notificationServiceCode
